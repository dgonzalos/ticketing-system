# SETUP CLAUDE EN WINDOWS 11 — Terminal First

## PARTE 1: PLANES DE CLAUDE

### Comparativa

| Aspecto | Free (Claude.ai) | Claude Pro | Claude Team | Claude API |
|---------|------------------|-----------|-----------|-----------|
| **Costo** | Gratis | $20/mes | $30/usuario/mes | Pay-as-you-go |
| **Mensajes/día** | 40 | 500+ | Limitado por plan | Sin límite |
| **Acceso** | Web | Web | Web + API | API solo |
| **Para quién** | Experimentar | Uso individual | Equipos pequeños | Desarrollo/Producción |
| **Claude Code** | No | Sí | Sí | No (pero API) |
| **Prioridad** | Baja | Media | Alta | N/A |
| **Contexto** | 200k tokens | 200k tokens | 200k tokens | 200k tokens |

---

## PARA TU PROYECTO: RECOMENDACIÓN

### Opción A: **Claude Pro** (RECOMENDADO para desarrollo)

**Por qué:**
- ✅ $20/mes (barato)
- ✅ Claude Code (desarrollo agentic)
- ✅ 500+ mensajes/día (suficiente)
- ✅ Acceso inmediato a nuevas features
- ✅ Mejor para iteraciones rápidas

**Flujo:**
```
Terminal → Claude Code
       ↓
Git repo → cambios automáticos
       ↓
Pruebas/feedback → otro Claude Code call
```

### Opción B: Claude API (DESPUÉS, para producción)

**Cuándo pasarse:**
- Cuando tengas backend listo
- Cuando necesites integrar Claude EN la app (tool use, MCP)
- Cuando necesites llamadas programáticas

**Costo estimado para tu proyecto:**
- Tool use (búsqueda): ~$0.05 por búsqueda × 100/día = $5/mes
- Structured outputs (análisis): ~$0.08 × 10/día = $2.40/mes
- MCP admin queries: ~$0.05 × 5/día = $1.25/mes
- **Total: ~$8-10/mes en producción**

### Plan sugerido: **Claude Pro ahora + Claude API después**

---

## PARTE 2: SETUP WINDOWS 11

### PASO 1: Instalar Claude Code (Recomendado)

Claude Code es una herramienta agentic que funciona en terminal.

#### 1.1 Requisitos

```powershell
# Verificar que tienes Node.js 18+
node --version
npm --version

# Si no tienes, descargar de https://nodejs.org
# Descarga LTS (recomendado)
```

#### 1.2 Instalar Claude Code

```powershell
# PowerShell (ejecutar como admin)

# Opción A: Instalar globalmente
npm install -g @anthropic-ai/claude-code

# Opción B: Instalar en tu proyecto (mejor)
cd tu-ticketing-system
npm install --save-dev @anthropic-ai/claude-code
```

#### 1.3 Configurar API Key

```powershell
# Crear variable de entorno en Windows

# Opción A: PowerShell (temporal, solo esta sesión)
$env:ANTHROPIC_API_KEY="sk-ant-..."

# Opción B: PowerShell (permanente)
# Abrir PowerShell como admin y ejecutar:
[Environment]::SetEnvironmentVariable("ANTHROPIC_API_KEY", "sk-ant-...", "User")

# Luego reiniciar PowerShell

# Verificar
$env:ANTHROPIC_API_KEY
```

**¿Dónde obtener la API Key?**
1. Ir a https://console.anthropic.com
2. Crear cuenta (con email)
3. Ir a "API Keys"
4. Crear nueva key
5. Copiar y guardar (⚠️ no se puede recuperar)

#### 1.4 Crear archivo .env en tu proyecto

```powershell
# En la raíz de ticketing-system/

type .env.example
# Copiar contenido y crear .env

# .env
ANTHROPIC_API_KEY=sk-ant-...
```

---

### PASO 2: Setup Git + Terminal Workflow

#### 2.1 Configurar Git en Windows

```powershell
# Instalar Git for Windows desde https://git-scm.com

# Verificar
git --version

# Configurar
git config --global user.name "Tu Nombre"
git config --global user.email "tu@email.com"
```

#### 2.2 Crear estructura inicial

```powershell
cd ~
mkdir dev
cd dev
mkdir ticketing-system
cd ticketing-system

git init
git config user.email "tu@email.com"
git config user.name "Diego"
```

---

### PASO 3: Herramientas CLI para usar Claude

#### Opción A: Claude Code (Recomendada para desarrollo)

```powershell
# Usar directamente en terminal

claude-code --help

# Ejemplo: Crear un archivo TypeScript
claude-code create "Crear SeatLockManager.ts en packages/api/src/domain/seats"

# Ejemplo: Revisar código
claude-code review packages/api/src/domain/seats/seat-lock.ts

# Ejemplo: Escribir tests
claude-code test "Escribir tests para SeatLockManager con Vitest"
```

#### Opción B: Usar Claude.ai Web + Terminal

```powershell
# Abrir Claude en navegador
Start-Process "https://claude.ai"

# Copiar/pegar código entre terminal y Claude.ai
# Útil para:
# - Ver archivos en paralelo
# - Iteraciones rápidas
# - Revisar complex structures
```

#### Opción C: Curl + API (Para integración después)

```powershell
# Ejemplo: Llamar Claude API desde PowerShell

$headers = @{
    "x-api-key" = $env:ANTHROPIC_API_KEY
    "anthropic-version" = "2023-06-01"
    "content-type" = "application/json"
}

$body = @{
    model = "claude-opus-4"
    max_tokens = 1024
    messages = @(
        @{
            role = "user"
            content = "Hola, soy Diego"
        }
    )
} | ConvertTo-Json

$response = Invoke-WebRequest `
    -Uri "https://api.anthropic.com/v1/messages" `
    -Method Post `
    -Headers $headers `
    -Body $body

$response.Content | ConvertFrom-Json
```

---

## PARTE 3: SETUP RECOMENDADO PARA TU PROYECTO

### 3.1 Estructura de directorios

```
C:\Users\Diego\dev\
└── ticketing-system/
    ├── .git/
    ├── .env
    ├── .env.example
    ├── .gitignore
    ├── packages/
    │   ├── api/
    │   ├── web/
    │   └── shared/
    ├── docs/
    ├── package.json
    └── pnpm-workspace.yaml
```

### 3.2 Windows Terminal Setup (Opcional pero recomendado)

**Instalar Windows Terminal:**
1. Microsoft Store → Buscar "Windows Terminal" → Instalar
2. Es mejor que PowerShell por defecto

**Configurar perfil en `settings.json`:**

```json
{
  "profiles": {
    "defaults": {
      "font": {
        "face": "Cascadia Code",
        "size": 10
      }
    },
    "list": [
      {
        "name": "PowerShell",
        "commandline": "pwsh.exe",
        "startingDirectory": "C:\\Users\\Diego\\dev\\ticketing-system",
        "icon": "ms-appx:///Microsoft.PowerShell_8wekyb3d8bbwe?ms-resource://Microsoft.PowerShell/en/Resources/AppIcon.ico"
      }
    ]
  }
}
```

### 3.3 Alias útiles en PowerShell

```powershell
# Editar perfil de PowerShell
notepad $PROFILE

# Agregar estos alias

# Claude Code shortcuts
function claude-create {
    param([string]$desc)
    claude-code create $desc
}

function claude-review {
    param([string]$file)
    claude-code review $file
}

# Git shortcuts
function ga {
    git add .
}

function gc {
    param([string]$msg)
    git commit -m $msg
}

# NPM shortcuts
function pnpm-dev {
    pnpm dev
}

# Guardar y recargar
. $PROFILE
```

Luego en terminal:

```powershell
# Ahora puedes hacer:
claude-create "Crear SeatService.ts"
ga
gc "feat: add seat service"
pnpm-dev
```

---

## PARTE 4: WORKFLOWS RECOMENDADOS

### FLUJO 1: Desarrollo con Claude Code (Diario)

```powershell
# Terminal 1: Editor + Claude Code
cd C:\Users\Diego\dev\ticketing-system

# Pedir a Claude que cree feature
claude-code create "Implementar SeatLockManager con SELECT FOR UPDATE"

# Claude genera el código automáticamente
# Revisa el archivo generado en VSCode

# Confirmar y commitear
git add packages/api/src/domain/seats/
git commit -m "feat: implement seat lock manager"

# Pedir tests
claude-code test "Escribir tests de concurrencia para SeatLockManager"

# Revisar tests
git add packages/api/tests/
git commit -m "test: add concurrency tests"

# Ejecutar
pnpm -r --filter @ticketing/api test
```

### FLUJO 2: Investigación + Iteración (Cuando estés atascado)

```powershell
# Terminal
# 1. Abrir Claude en navegador paralelo
Start-Process "https://claude.ai"

# 2. Pedir ayuda con contexto
# En Claude.ai:
# - Copiar el error
# - Copiar el código relevante
# - Pregunta específica

# 3. Claude te da solución
# 4. Copiar solución al terminal
# 5. Ejecutar

npm run test
```

### FLUJO 3: Análisis de arquitectura

```powershell
# Para preguntas sobre arquitectura grandes

# 1. Crear archivo temporal
@"
# Ticketing System Backend Architecture

## Current structure
- api/ (Fastify)
- domain/ (Services + Repos)
- infrastructure/ (DB)

## Question
¿Cómo debería estructurar el MCP server?
¿Compartir ToolsRegistry con API layer?

## Context
- Ya tengo SearchEventsTool funcionando
- Necesito AnalyzeSalesTool
- Quiero evitar duplicación

"@ | Out-File analyze.md

# 2. Mostrar a Claude en navegador
notepad analyze.md
# (copiar a Claude.ai)

# 3. Claude da feedback
# 4. Implementar recomendación
```

---

## PARTE 5: CONFIGURACIÓN VS CODE (RECOMENDADO)

### 5.1 Instalar VS Code

Descargar desde https://code.visualstudio.com

### 5.2 Extensiones recomendadas

```powershell
# Instalar via terminal
code --install-extension ms-vscode.typescript-vue
code --install-extension ms-vscode-docker.remote-containers
code --install-extension GitHub.copilot
code --install-extension TabNine.tabnine-vscode
code --install-extension esbenp.prettier-vscode
code --install-extension dbaeumer.vscode-eslint
```

### 5.3 Settings.json

```json
{
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.formatOnSave": true,
  "editor.fontSize": 13,
  "editor.fontFamily": "Cascadia Code",
  "files.autoSave": "afterDelay",
  "typescript.tsdk": "node_modules/typescript/lib",
  "typescript.enablePromptUseWorkspaceTsdk": true,
  "[markdown]": {
    "editor.defaultFormatter": "esbenp.prettier-vscode"
  }
}
```

---

## PARTE 6: PRIMEROS PASOS (PASO A PASO)

### Paso 1: Crear directorio y Git

```powershell
cd $HOME\dev
mkdir ticketing-system
cd ticketing-system

git init
git config user.email "diego@example.com"
git config user.name "Diego"

# Crear archivos básicos
type .env.example > .env
type .gitignore > .gitignore
```

### Paso 2: Obtener API Key

```
1. Ir a https://console.anthropic.com
2. Sign up
3. API Keys → Create Key
4. Copiar key
```

### Paso 3: Configurar variable de entorno

```powershell
# PowerShell como admin
[Environment]::SetEnvironmentVariable("ANTHROPIC_API_KEY", "sk-ant-...", "User")

# Cerrar PowerShell y abrir de nuevo

# Verificar
echo $env:ANTHROPIC_API_KEY
# Debería mostrar tu key
```

### Paso 4: Instalar Claude Code

```powershell
npm install -g @anthropic-ai/claude-code

# Verificar
claude-code --version
```

### Paso 5: Primer comando

```powershell
cd ~\dev\ticketing-system

# Pedir a Claude que cree la estructura inicial
claude-code create "Crear estructura de monorepo con pnpm (packages/api, packages/web, packages/shared)"

# Claude va a crear los archivos
# Esperar a que termine

# Revisar archivos creados
dir

# Commitear
git add .
git commit -m "chore: initial project setup via claude-code"
```

---

## PARTE 7: USANDO CLAUDE API DESPUÉS (Producción)

Una vez que tengas el backend listo y quieras integrar Claude:

### 7.1 Instalar SDK

```powershell
cd packages/api

npm install @anthropic-ai/sdk
npm install --save-dev @types/node
```

### 7.2 Crear cliente

```typescript
// packages/api/src/infrastructure/claude-client.ts

import Anthropic from "@anthropic-ai/sdk";

export const claudeClient = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// Uso en tu código
const response = await claudeClient.messages.create({
  model: "claude-opus-4",
  max_tokens: 1024,
  messages: [
    {
      role: "user",
      content: "Tu prompt aquí"
    }
  ]
});
```

### 7.3 Ejemplo: Integrar SearchHandler

```typescript
// Ya tienes esto
const response = await claudeClient.messages.create({
  model: "claude-opus-4",
  max_tokens: 2048,
  tools: toolsRegistry.getDefinitions(),
  messages: [
    { role: "user", content: userQuery }
  ]
});

// Claude automáticamente llama tus tools
// y hace multi-turn reasoning
```

---

## RESUMEN: ¿QUÉ COMPRAR HOY?

### Opción recomendada: **Claude Pro ($20/mes)**

**Pasos:**
1. ✅ Ir a https://claude.ai
2. ✅ Crear cuenta
3. ✅ Upgrade a Pro ($20/mes)
4. ✅ Ir a https://console.anthropic.com (crear cuenta distinta)
5. ✅ Crear API Key
6. ✅ Guardar API Key en `ANTHROPIC_API_KEY`

**Total costo inicial:**
- Claude Pro: $20/mes
- Dominio (opcional): $12/año
- Hosting (después): $5-10/mes
- **Total: ~$25-30/mes**

---

## CHECKLIST SETUP FINAL

- [ ] Node.js 18+ instalado
- [ ] Claude Pro ($20/mes) activo
- [ ] API Key generada en console.anthropic.com
- [ ] ANTHROPIC_API_KEY en variables de entorno
- [ ] Claude Code instalado (`npm install -g @anthropic-ai/claude-code`)
- [ ] Git configurado
- [ ] Estructura de proyecto creada
- [ ] Primer commit hecho
- [ ] VS Code instalado (opcional)
- [ ] Windows Terminal instalado (opcional)

---

## COMANDOS PRINCIPALES

```powershell
# Desarrollo
claude-code create "descripción de qué crear"
claude-code review "path/to/file"
claude-code test "descripción de tests"

# Git
git add .
git commit -m "mensaje"
git push

# NPM/PNPM
pnpm install
pnpm dev
pnpm test

# Usar API (después)
npm install @anthropic-ai/sdk
# Ver ejemplo en PARTE 7
```

---

## RECURSOS

- **Claude Code Docs**: https://docs.claude.com/en/docs/claude-code/overview
- **Claude API Docs**: https://docs.claude.com/en/api/overview
- **Anthropic Console**: https://console.anthropic.com
- **Node.js**: https://nodejs.org (LTS)
- **Git**: https://git-scm.com
- **VS Code**: https://code.visualstudio.com
- **Windows Terminal**: Microsoft Store

---

## TL;DR

```
1. Compra Claude Pro ($20/mes)
2. Instala Node.js + Git + Claude Code
3. Configura ANTHROPIC_API_KEY
4. Usa claude-code create "descripción"
5. Commitea a Git
6. Cuando tengas backend → integra Claude API
```

**¿Dudas? Pregunta en terminal y Claude te ayuda. ¡Eso es el punto!** 🚀

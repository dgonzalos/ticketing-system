# Setup Inicial — Ticketing System

## Paso 1: Crear el repositorio

```bash
# Crear directorio
mkdir ticketing-system && cd ticketing-system

# Inicializar Git
git init
git config user.email "tu@email.com"
git config user.name "Tu Nombre"

# Crear rama principal
git checkout -b main
```

## Paso 2: Setup de Monorepo con pnpm

```bash
# Instalar pnpm globalmente (si no lo tienes)
npm install -g pnpm

# Crear pnpm-workspace.yaml en la raíz
cat > pnpm-workspace.yaml << 'EOF'
packages:
  - 'packages/*'
  - 'infrastructure'
EOF

# Crear root package.json
cat > package.json << 'EOF'
{
  "name": "ticketing-system",
  "version": "1.0.0",
  "description": "Full-stack event ticketing with Claude AI & MCP",
  "private": true,
  "scripts": {
    "dev": "pnpm -r --parallel run dev",
    "build": "pnpm -r run build",
    "test": "pnpm -r run test",
    "lint": "pnpm -r run lint"
  },
  "devDependencies": {
    "typescript": "^5.3.0"
  }
}
EOF

pnpm install
```

## Paso 3: Crear estructura de carpetas

```bash
# Crear directorios principales
mkdir -p packages/{api,web,shared,mcp-server}
mkdir -p infrastructure/{postgres,nginx}
mkdir -p docs

# Crear .github/workflows
mkdir -p .github/workflows

# Crear archivos raíz importantes
touch .env.example
touch .gitignore
touch README.md
touch ARCHITECTURE.md
```

## Paso 4: Backend (Fastify + Claude)

### 4.1 Crear package.json del backend

```bash
cd packages/api

cat > package.json << 'EOF'
{
  "name": "@ticketing/api",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "tsx watch src/index.ts",
    "build": "tsc",
    "start": "node dist/index.js",
    "test": "vitest",
    "test:coverage": "vitest --coverage",
    "lint": "eslint src --fix"
  },
  "dependencies": {
    "fastify": "^4.24.0",
    "@fastify/cors": "^8.4.2",
    "@fastify/jwt": "^7.8.0",
    "typescript": "^5.3.0",
    "@anthropic-ai/sdk": "^0.9.0",
    "drizzle-orm": "^0.28.0",
    "drizzle-kit": "^0.20.0",
    "postgres": "^3.4.0",
    "zod": "^3.22.0",
    "pino": "^8.17.0",
    "uuid": "^9.0.0",
    "dotenv": "^16.3.1"
  },
  "devDependencies": {
    "tsx": "^4.6.0",
    "@types/node": "^20.10.0",
    "typescript": "^5.3.0",
    "vitest": "^1.0.0",
    "@vitest/coverage-v8": "^1.0.0",
    "eslint": "^8.55.0"
  }
}
EOF

pnpm install
```

### 4.2 Crear estructura base

```bash
# Estructura de carpetas del API
mkdir -p src/{api,domain,ai,mcp,infrastructure}

# Crear index.ts básico
cat > src/index.ts << 'EOF'
import Fastify from 'fastify';
import cors from '@fastify/cors';

const app = Fastify({ logger: true });

await app.register(cors);

// Routes
app.get('/health', async () => {
  return { status: 'ok' };
});

const start = async () => {
  try {
    await app.listen({ port: 3000, host: '0.0.0.0' });
    console.log('Server running at http://localhost:3000');
  } catch (err) {
    app.log.error(err);
    process.exit(1);
  }
};

start();
EOF

# TypeScript config
cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "ESNext",
    "lib": ["ES2020"],
    "moduleResolution": "node",
    "esModuleInterop": true,
    "skipLibCheck": true,
    "strict": true,
    "resolveJsonModule": true,
    "outDir": "./dist",
    "rootDir": "./src",
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }
  },
  "include": ["src"],
  "exclude": ["node_modules", "dist"]
}
EOF
```

### 4.3 Crear Dockerfile del API

```bash
cat > Dockerfile << 'EOF'
FROM node:20-alpine

WORKDIR /app

# Instalar pnpm
RUN npm install -g pnpm

# Copiar workspace
COPY pnpm-workspace.yaml .
COPY packages/api ./packages/api
COPY packages/shared ./packages/shared
COPY package.json pnpm-lock.yaml ./

# Instalar dependencias
RUN pnpm install --frozen-lockfile

# Build
RUN pnpm -r run build

# Runtime
EXPOSE 3000
CMD ["pnpm", "-r", "--filter", "@ticketing/api", "start"]
EOF
```

## Paso 5: Frontend (React + Vite)

### 5.1 Crear proyecto con Vite

```bash
cd packages/web

pnpm create vite . --template react-ts

# Instalar dependencias adicionales
pnpm add \
  @tanstack/react-query@latest \
  react-router-dom@latest \
  zod@latest \
  tailwindcss@latest \
  postcss@latest \
  autoprefixer@latest
```

### 5.2 Setup Tailwind

```bash
pnpm dlx tailwindcss init -p

# Editar tailwind.config.js
cat > tailwind.config.js << 'EOF'
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
EOF
```

### 5.3 Crear estructura de carpetas

```bash
mkdir -p src/{components,features,lib,hooks,types,theme}

# Crear tipos base
cat > src/types/index.ts << 'EOF'
export interface Event {
  id: string;
  title: string;
  description: string;
  genre: string;
}

export interface Performance {
  id: string;
  eventId: string;
  date: string;
  venue: string;
  capacity: number;
}

export interface Seat {
  id: string;
  performanceId: string;
  row: string;
  number: number;
  zone: string;
  price: number;
  status: 'available' | 'reserved' | 'sold' | 'blocked';
}
EOF

# Crear API client
cat > src/lib/api.ts << 'EOF'
const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export const api = {
  async get<T>(endpoint: string): Promise<T> {
    const res = await fetch(`${API_BASE}${endpoint}`);
    if (!res.ok) throw new Error(`API error: ${res.statusText}`);
    return res.json();
  },

  async post<T>(endpoint: string, body: unknown): Promise<T> {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) throw new Error(`API error: ${res.statusText}`);
    return res.json();
  }
};
EOF
```

### 5.4 Crear .env.local

```bash
cat > .env.local << 'EOF'
VITE_API_URL=http://localhost:3000
EOF
```

## Paso 6: Database (PostgreSQL)

### 6.1 Crear docker-compose.yml

En la raíz del proyecto:

```bash
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_USER: ticketing
      POSTGRES_PASSWORD: dev_password
      POSTGRES_DB: ticketing_dev
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./infrastructure/postgres/init.sql:/docker-entrypoint-initdb.d/init.sql
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ticketing"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

volumes:
  postgres_data:
EOF
```

### 6.2 Crear init.sql

```bash
cat > infrastructure/postgres/init.sql << 'EOF'
-- Extensiones
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";

-- Tables irán aquí en los pasos siguientes
EOF
```

## Paso 7: .env.example y .gitignore

```bash
# En la raíz del proyecto

cat > .env.example << 'EOF'
# Backend
NODE_ENV=development
DATABASE_URL=postgresql://ticketing:dev_password@localhost:5432/ticketing_dev
JWT_SECRET=your-secret-key-change-in-production
PORT=3000

# Claude API
ANTHROPIC_API_KEY=sk-ant-...

# Frontend
VITE_API_URL=http://localhost:3000
EOF

cat > .gitignore << 'EOF'
# Dependencies
node_modules/
.pnpm-store/

# Environment
.env
.env.local
.env.*.local

# Build
dist/
build/
.tsc

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log
npm-debug.log*
pnpm-debug.log*

# Test coverage
coverage/

# Database
*.sqlite
.postgres/
EOF
```

## Paso 8: GitHub Actions CI/CD

```bash
# Crear workflow para tests
cat > .github/workflows/test.yml << 'EOF'
name: Tests

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:15-alpine
        env:
          POSTGRES_USER: ticketing
          POSTGRES_PASSWORD: test
          POSTGRES_DB: ticketing_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

    steps:
      - uses: actions/checkout@v4
      
      - uses: pnpm/action-setup@v2
        with:
          version: 8
      
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'pnpm'
      
      - run: pnpm install --frozen-lockfile
      
      - run: pnpm build
      
      - run: pnpm test
EOF
```

## Paso 9: Commit inicial

```bash
# Desde la raíz del proyecto
git add .
git commit -m "chore: initial project setup

- Monorepo structure with pnpm workspaces
- Backend: Fastify + TypeScript + Claude API
- Frontend: React + Vite + TanStack Query
- Database: PostgreSQL + Docker Compose
- CI/CD: GitHub Actions
"

git branch -M main
# git remote add origin <tu-repo-url>
# git push -u origin main
```

## Paso 10: Verificar que funciona

```bash
# Terminal 1: Base de datos
docker-compose up

# Terminal 2: Backend
cd packages/api
pnpm dev

# Terminal 3: Frontend
cd packages/web
pnpm dev
```

Debería ver:
- Frontend en http://localhost:5173
- Backend en http://localhost:3000
- Database en localhost:5432

---

## Siguientes pasos

1. **Crear las primeras features** (Domain models)
2. **Implementar autenticación** (JWT + Fastify)
3. **Integrar Claude API** (Search con tool use)
4. **Tests unitarios** (Vitest)
5. **Documentación** (README + ARCHITECTURE.md)

---

## Recursos útiles

- [Fastify Docs](https://www.fastify.io/)
- [Vite Docs](https://vitejs.dev/)
- [Drizzle ORM](https://orm.drizzle.team/)
- [Anthropic SDK](https://github.com/anthropics/anthropic-sdk-python)
- [pnpm Workspaces](https://pnpm.io/workspaces)

# Backend Architecture — Ticketing System

## 1. ESTRUCTURA DE CARPETAS

```
packages/api/
├── src/
│   ├── api/                          # HTTP Layer
│   │   ├── routes/
│   │   │   ├── events.ts             # GET/POST /events
│   │   │   ├── performances.ts       # GET/POST /performances
│   │   │   ├── seats.ts              # GET /performances/:id/seats
│   │   │   ├── orders.ts             # POST /orders, GET /orders/:id
│   │   │   ├── search.ts             # POST /search (Claude AI)
│   │   │   └── auth.ts               # POST /auth/login, /auth/refresh
│   │   │
│   │   └── middleware/
│   │       ├── auth.ts               # JWT validation
│   │       ├── validation.ts         # Request validation (Zod)
│   │       ├── error-handler.ts      # Global error handling
│   │       └── logger.ts             # Request logging
│   │
│   ├── domain/                       # Business Logic Layer
│   │   ├── events/
│   │   │   ├── event.entity.ts       # Entity definition
│   │   │   ├── event.repository.ts   # Database operations
│   │   │   ├── event.service.ts      # Business rules
│   │   │   └── event.dto.ts          # Data transfer objects
│   │   │
│   │   ├── performances/
│   │   │   ├── performance.entity.ts
│   │   │   ├── performance.repository.ts
│   │   │   ├── performance.service.ts
│   │   │   └── performance.dto.ts
│   │   │
│   │   ├── seats/
│   │   │   ├── seat.entity.ts
│   │   │   ├── seat.repository.ts
│   │   │   ├── seat.service.ts
│   │   │   ├── seat-lock.ts          # Temporal lock logic
│   │   │   ├── concurrency.ts        # Handle race conditions
│   │   │   └── seat.dto.ts
│   │   │
│   │   ├── orders/
│   │   │   ├── order.entity.ts
│   │   │   ├── order.repository.ts
│   │   │   ├── order.service.ts
│   │   │   └── order.dto.ts
│   │   │
│   │   ├── users/
│   │   │   ├── user.entity.ts
│   │   │   ├── user.repository.ts
│   │   │   ├── user.service.ts       # Auth logic
│   │   │   └── user.dto.ts
│   │   │
│   │   └── common/
│   │       ├── value-objects.ts      # Price, Email, UUID types
│   │       ├── errors.ts             # Domain-specific exceptions
│   │       └── types.ts              # Shared types
│   │
│   ├── ai/                           # Claude AI Integration
│   │   ├── claude-client.ts          # Anthropic SDK wrapper
│   │   │
│   │   ├── tools/
│   │   │   ├── search-events.ts      # Tool: search events
│   │   │   ├── get-details.ts        # Tool: event details
│   │   │   ├── check-availability.ts # Tool: seat availability
│   │   │   └── tools.registry.ts     # Register all tools
│   │   │
│   │   ├── schemas/                  # Zod schemas for structured outputs
│   │   │   ├── event-analysis.ts
│   │   │   ├── fraud-detection.ts
│   │   │   └── price-optimization.ts
│   │   │
│   │   └── handlers/
│   │       ├── search-handler.ts     # Multi-turn search logic
│   │       └── analysis-handler.ts   # Analytics logic
│   │
│   ├── mcp/                          # Model Context Protocol Server
│   │   ├── server.ts                 # MCP server setup
│   │   │
│   │   ├── tools/
│   │   │   ├── analyze-sales.ts
│   │   │   ├── detect-fraud.ts
│   │   │   ├── price-optimization.ts
│   │   │   └── tools.registry.ts
│   │   │
│   │   ├── resources/
│   │   │   ├── analytics.ts          # Analytics data resources
│   │   │   ├── forecasts.ts          # Forecast resources
│   │   │   └── resources.registry.ts
│   │   │
│   │   └── prompts/                  # System prompts for MCP
│   │       └── admin-assistant.ts
│   │
│   ├── infrastructure/               # Infrastructure Layer
│   │   ├── db/
│   │   │   ├── connection.ts         # Database connection
│   │   │   ├── schema.ts             # Drizzle schema (entities)
│   │   │   ├── migrations/
│   │   │   │   ├── 001_init.ts
│   │   │   │   ├── 002_seats.ts
│   │   │   │   └── 003_analytics.ts
│   │   │   └── seeds/
│   │   │       ├── events.seed.ts
│   │   │       └── performances.seed.ts
│   │   │
│   │   ├── cache.ts                  # Redis client
│   │   ├── config.ts                 # Environment config
│   │   ├── logger.ts                 # Pino logger setup
│   │   └── email.ts                  # Email service (future)
│   │
│   ├── shared/                       # Shared utilities
│   │   ├── validation.ts             # Zod schemas
│   │   ├── errors.ts                 # HTTP error classes
│   │   ├── types.ts                  # Global types
│   │   └── utils.ts                  # Helper functions
│   │
│   └── app.ts                        # Fastify app setup
│
├── tests/
│   ├── unit/
│   │   ├── domain/
│   │   │   ├── events.service.test.ts
│   │   │   ├── seats.service.test.ts
│   │   │   └── orders.service.test.ts
│   │   │
│   │   ├── ai/
│   │   │   ├── tools.test.ts
│   │   │   └── handlers.test.ts
│   │   │
│   │   └── infrastructure/
│   │       └── db.test.ts
│   │
│   ├── integration/
│   │   ├── events.api.test.ts
│   │   ├── orders.api.test.ts
│   │   ├── search.api.test.ts
│   │   └── concurrency.test.ts
│   │
│   └── fixtures/
│       ├── users.fixture.ts
│       ├── events.fixture.ts
│       └── performances.fixture.ts
│
├── Dockerfile
├── docker-compose.yml
├── .env.example
├── tsconfig.json
├── vitest.config.ts
└── package.json
```

---

## 2. ARQUITECTURA DE CAPAS

```
                          ┌─────────────────┐
                          │  HTTP Requests  │
                          └────────┬────────┘
                                   │
                    ┌──────────────▼──────────────┐
                    │    API Layer (routes)       │
                    │  • Request parsing          │
                    │  • Response formatting      │
                    │  • HTTP status codes        │
                    └──────────────┬──────────────┘
                                   │
         ┌─────────────────────────┼─────────────────────────┐
         │                         │                         │
    ┌────▼────┐            ┌───────▼───────┐         ┌──────▼──────┐
    │ Middleware          │ Domain Layer  │         │ AI Layer    │
    │ • Auth              │ • Services    │         │ • Tools     │
    │ • Validation        │ • Repos       │         │ • Schemas   │
    │ • Errors            │ • Entities    │         │ • Handlers  │
    └────┬────┘            └───────┬───────┘         └──────┬──────┘
         │                         │                        │
         └─────────────────────────┼────────────────────────┘
                                   │
                    ┌──────────────▼──────────────┐
                    │ Infrastructure Layer        │
                    │ • Database (Drizzle ORM)    │
                    │ • Cache (Redis)             │
                    │ • Config                    │
                    └──────────────┬──────────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              │                    │                    │
         ┌────▼────┐          ┌────▼────┐          ┌───▼────┐
         │PostgreSQL│          │ Redis   │          │ Claude │
         │ + pgvector         │         │          │ API    │
         └─────────┘          └────────┘          └────────┘
```

---

## 3. FLUJO DE DATOS (Ejemplo: Buscar eventos)

```
POST /api/search
│
├─ req.body: { query: "eventos románticos" }
│
├─ Middleware
│  ├─ Auth: validar JWT ✓
│  └─ Validation: Zod schema ✓
│
├─ Route handler (search.ts)
│  └─ Call searchHandler.handle(query)
│
├─ AI Handler (search-handler.ts)
│  │
│  ├─ Call Claude with tools
│  │  ├─ Claude lee: "eventos románticos"
│  │  ├─ Decide: necesita search_events + get_details
│  │  │
│  │  ├─ Tool call 1: search_events
│  │  │  └─ SearchEventsTool.execute({ genres: ['music', 'theater'] })
│  │  │     └─ EventService.search(filters)
│  │  │        └─ EventRepository.findByFilters()
│  │  │           └─ DB query (Drizzle)
│  │  │              └─ Retorna eventos[]
│  │  │
│  │  ├─ Tool call 2: get_details
│  │  │  └─ GetDetailsTool.execute({ eventIds: [...] })
│  │  │     └─ EventService.getDetails()
│  │  │        └─ EventRepository.findByIds()
│  │  │           └─ DB query con embeddings
│  │  │              └─ Retorna eventos con embeddings
│  │  │
│  │  └─ Claude retorna respuesta: "Te recomiendo..."
│  │
│  └─ Retorna { recommendations: [], reasoning: "" }
│
├─ Response formatter
│  └─ { success: true, data: {...} }
│
└─ HTTP 200 + JSON
```

---

## 4. CAPAS DETALLADAS

### 4.1 API Layer (HTTP)

```typescript
// packages/api/src/api/routes/search.ts

import { FastifyRequest, FastifyReply } from 'fastify';
import { SearchHandler } from '@/ai/handlers/search-handler';
import { SearchQuerySchema } from '@/shared/validation';

export async function searchRoutes(app: FastifyInstance) {
  app.post(
    '/search',
    {
      // Middleware: requiere autenticación
      onRequest: [app.authenticate],
      // Validación automática con Zod
      schema: {
        body: SearchQuerySchema,
      }
    },
    async (req: FastifyRequest, reply: FastifyReply) => {
      try {
        const { query } = req.body;
        const userId = req.user.id;
        
        // Delegar a handler
        const result = await SearchHandler.handle(query, userId);
        
        // Retornar respuesta tipada
        return reply.code(200).send({
          success: true,
          data: result,
        });
      } catch (error) {
        // Error handler automático (middleware)
        throw error;
      }
    }
  );
}
```

**Características:**
- ✅ Type-safe requests/responses
- ✅ Validation automática
- ✅ Auth middleware
- ✅ Error handling centralizado

---

### 4.2 Domain Layer (Business Logic)

```typescript
// packages/api/src/domain/events/event.service.ts

import { EventRepository } from './event.repository';
import { EventDTO } from './event.dto';
import { DomainError } from '@/domain/common/errors';

export class EventService {
  constructor(private repo: EventRepository) {}

  /**
   * Search events by various criteria
   * Uses similarity search with pgvector
   */
  async search(filters: {
    genres?: string[];
    priceRange?: [number, number];
    fromDate?: Date;
    toDate?: Date;
    query?: string;
  }): Promise<EventDTO[]> {
    // Validación de dominio
    if (filters.priceRange) {
      const [min, max] = filters.priceRange;
      if (min < 0 || max < min) {
        throw new DomainError('INVALID_PRICE_RANGE', 'Price range must be valid');
      }
    }

    // Lógica de búsqueda
    if (filters.query) {
      // Si hay query de texto, usar pgvector para búsqueda semántica
      return await this.repo.searchBySimilarity(filters.query, filters);
    }

    // Si no, búsqueda por filtros
    return await this.repo.findByFilters(filters);
  }

  /**
   * Get event details with availability
   */
  async getDetails(eventId: string): Promise<EventDTO> {
    const event = await this.repo.findById(eventId);
    
    if (!event) {
      throw new DomainError('EVENT_NOT_FOUND', `Event ${eventId} not found`);
    }

    // Enriquecer con datos de disponibilidad
    const performances = await this.repo.getPerformances(eventId);
    const avgPrice = this.calculateAveragePrice(performances);

    return {
      ...event,
      performances,
      avgPrice,
    };
  }

  private calculateAveragePrice(performances: any[]): number {
    const prices = performances.flatMap(p => p.seats.map(s => s.price));
    return prices.reduce((a, b) => a + b, 0) / prices.length;
  }
}
```

**Características:**
- ✅ Business rules encapsulated
- ✅ No HTTP concerns
- ✅ Testeable en aislamiento
- ✅ Reutilizable desde API y MCP

---

### 4.3 Repository Layer (Data Access)

```typescript
// packages/api/src/domain/events/event.repository.ts

import { db } from '@/infrastructure/db/connection';
import { eventsTable, performancesTable, seatsTable } from '@/infrastructure/db/schema';
import { cosineDistance } from 'drizzle-orm';

export class EventRepository {
  /**
   * Search by vector similarity (pgvector)
   * Encuentra eventos similares a una descripción
   */
  async searchBySimilarity(
    query: string,
    filters: { genres?: string[]; priceRange?: [number, number] }
  ) {
    // Generar embedding de la query con Claude
    const queryEmbedding = await this.generateEmbedding(query);

    // Buscar con pgvector
    let q = db
      .select({
        id: eventsTable.id,
        title: eventsTable.title,
        genre: eventsTable.genre,
        similarity: cosineDistance(eventsTable.embedding, queryEmbedding),
      })
      .from(eventsTable)
      .orderBy((t) => t.similarity);

    // Aplicar filtros
    if (filters.genres?.length) {
      q = q.where(inArray(eventsTable.genre, filters.genres));
    }

    return q.limit(20).execute();
  }

  /**
   * Find events by filters
   */
  async findByFilters(filters: {
    genres?: string[];
    priceRange?: [number, number];
    fromDate?: Date;
    toDate?: Date;
  }) {
    let q = db.select().from(eventsTable);

    if (filters.genres?.length) {
      q = q.where(inArray(eventsTable.genre, filters.genres));
    }

    if (filters.priceRange) {
      const [min, max] = filters.priceRange;
      q = q
        .innerJoin(performancesTable, eq(eventsTable.id, performancesTable.eventId))
        .innerJoin(seatsTable, eq(performancesTable.id, seatsTable.performanceId))
        .where(between(seatsTable.price, min, max));
    }

    if (filters.fromDate && filters.toDate) {
      q = q.where(
        between(performancesTable.date, filters.fromDate, filters.toDate)
      );
    }

    return q.execute();
  }

  /**
   * Find by ID with related data
   */
  async findById(id: string) {
    return db
      .select()
      .from(eventsTable)
      .where(eq(eventsTable.id, id))
      .execute()
      .then((rows) => rows[0]);
  }

  /**
   * Generate embedding using Claude
   */
  private async generateEmbedding(text: string): Promise<number[]> {
    // Usar la API de embeddings de Claude
    const response = await fetch('https://api.anthropic.com/v1/text/embedding', {
      method: 'POST',
      headers: {
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'content-type': 'application/json',
      },
      body: JSON.stringify({ text }),
    });

    const data = await response.json();
    return data.embedding;
  }
}
```

**Características:**
- ✅ Queries tipadas con Drizzle
- ✅ pgvector para búsqueda semántica
- ✅ No mezcla con lógica de negocio
- ✅ Testeable con fixtures

---

### 4.4 AI Layer (Claude Integration)

```typescript
// packages/api/src/ai/tools/search-events.ts

import { z } from 'zod';
import { EventService } from '@/domain/events/event.service';

const SearchEventsToolInput = z.object({
  genres: z.array(z.string()).optional(),
  min_price: z.number().optional(),
  max_price: z.number().optional(),
  from_date: z.string().datetime().optional(),
  to_date: z.string().datetime().optional(),
});

type SearchEventsInput = z.infer<typeof SearchEventsToolInput>;

export class SearchEventsTool {
  private eventService: EventService;

  constructor(eventService: EventService) {
    this.eventService = eventService;
  }

  /**
   * Tool definition para Claude
   */
  getDefinition() {
    return {
      name: 'search_events',
      description:
        'Search for events by genre, price, and date. Returns list of matching events.',
      input_schema: {
        type: 'object' as const,
        properties: {
          genres: {
            type: 'array',
            items: { type: 'string' },
            description: 'Event genres (e.g., "music", "theater", "sports")',
          },
          min_price: {
            type: 'number',
            description: 'Minimum price for tickets',
          },
          max_price: {
            type: 'number',
            description: 'Maximum price for tickets',
          },
          from_date: {
            type: 'string',
            format: 'date-time',
            description: 'Start date for event search',
          },
          to_date: {
            type: 'string',
            format: 'date-time',
            description: 'End date for event search',
          },
        },
      },
    };
  }

  /**
   * Ejecutar tool
   */
  async execute(input: unknown) {
    try {
      const validated = SearchEventsToolInput.parse(input);

      const events = await this.eventService.search({
        genres: validated.genres,
        priceRange: validated.min_price
          ? [validated.min_price, validated.max_price ?? 1000]
          : undefined,
        fromDate: validated.from_date ? new Date(validated.from_date) : undefined,
        toDate: validated.to_date ? new Date(validated.to_date) : undefined,
      });

      return {
        success: true,
        data: events,
        count: events.length,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
}
```

**Características:**
- ✅ Zod schema validation
- ✅ Type-safe input/output
- ✅ Error handling
- ✅ Fácil de registrar en Claude

---

### 4.5 AI Handler (Orquestación)

```typescript
// packages/api/src/ai/handlers/search-handler.ts

import Anthropic from '@anthropic-ai/sdk';
import { SearchEventsTool } from '../tools/search-events';
import { GetDetailsTool } from '../tools/get-details';
import { CheckAvailabilityTool } from '../tools/check-availability';

export class SearchHandler {
  private client: Anthropic;
  private tools: any[];

  constructor() {
    this.client = new Anthropic();

    const eventService = new EventService(new EventRepository());
    const seatService = new SeatService(new SeatRepository());

    this.tools = [
      new SearchEventsTool(eventService),
      new GetDetailsTool(eventService),
      new CheckAvailabilityTool(seatService),
    ];
  }

  /**
   * Orquestar multi-turn conversation con Claude
   */
  async handle(query: string, userId: string): Promise<SearchResult> {
    const messages: MessageParam[] = [
      {
        role: 'user',
        content: query,
      },
    ];

    let continueLoop = true;
    let finalResult: SearchResult = { recommendations: [], reasoning: '' };

    while (continueLoop) {
      // Llamar a Claude con tools
      const response = await this.client.messages.create({
        model: 'claude-opus-4',
        max_tokens: 2048,
        tools: this.tools.map((t) => t.getDefinition()),
        messages,
      });

      // Procesar respuesta
      for (const block of response.content) {
        if (block.type === 'text') {
          // Guardar reasoning
          finalResult.reasoning = block.text;
        }

        if (block.type === 'tool_use') {
          // Ejecutar tool
          const tool = this.tools.find((t) =>
            t.getDefinition().name === block.name
          );
          const toolResult = await tool.execute(block.input);

          // Agregar resultado a messages para siguiente iteración
          messages.push({
            role: 'assistant',
            content: response.content,
          });

          messages.push({
            role: 'user',
            content: [
              {
                type: 'tool_result',
                tool_use_id: block.id,
                content: JSON.stringify(toolResult),
              },
            ],
          });

          // Si es search_events, guardar resultados
          if (block.name === 'search_events' && toolResult.success) {
            finalResult.recommendations = toolResult.data;
          }
        }
      }

      // Parar si Claude no usa más tools
      if (!response.content.some((b) => b.type === 'tool_use')) {
        continueLoop = false;
      }

      // Safety: máximo 5 iteraciones
      if (messages.length > 10) {
        continueLoop = false;
      }
    }

    return finalResult;
  }
}
```

**Características:**
- ✅ Multi-turn reasoning
- ✅ Automatic tool calling
- ✅ Type-safe tool results
- ✅ Safety limits

---

### 4.6 Infrastructure Layer (Acceso a datos)

```typescript
// packages/api/src/infrastructure/db/schema.ts

import { pgTable, text, integer, decimal, timestamp, vector } from 'drizzle-orm/pg-core';
import { createId } from '@paralleldrive/cuid2';

export const eventsTable = pgTable('events', {
  id: text('id').primaryKey().$defaultFn(() => createId()),
  title: text('title').notNull(),
  description: text('description'),
  genre: text('genre').notNull(),
  imageUrl: text('image_url'),
  embedding: vector('embedding', { dimensions: 1536 }), // OpenAI embeddings
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const performancesTable = pgTable('performances', {
  id: text('id').primaryKey().$defaultFn(() => createId()),
  eventId: text('event_id')
    .notNull()
    .references(() => eventsTable.id),
  date: timestamp('date').notNull(),
  venue: text('venue').notNull(),
  capacity: integer('capacity').notNull(),
  currentSales: integer('current_sales').default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const seatsTable = pgTable('seats', {
  id: text('id').primaryKey().$defaultFn(() => createId()),
  performanceId: text('performance_id')
    .notNull()
    .references(() => performancesTable.id),
  row: text('row').notNull(),
  number: integer('number').notNull(),
  zone: text('zone').notNull(),
  price: decimal('price', { precision: 10, scale: 2 }).notNull(),
  status: text('status').default('available').notNull(), // available, reserved, sold, blocked
  reservedUntil: timestamp('reserved_until'), // Expiración de reserva temporal
  reservedBy: text('reserved_by'), // Usuario que reservó
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const ordersTable = pgTable('orders', {
  id: text('id').primaryKey().$defaultFn(() => createId()),
  userId: text('user_id').notNull(),
  performanceId: text('performance_id')
    .notNull()
    .references(() => performancesTable.id),
  totalPrice: decimal('total_price', { precision: 10, scale: 2 }).notNull(),
  status: text('status').default('pending').notNull(), // pending, completed, cancelled
  createdAt: timestamp('created_at').defaultNow().notNull(),
  completedAt: timestamp('completed_at'),
});

export const orderItemsTable = pgTable('order_items', {
  id: text('id').primaryKey().$defaultFn(() => createId()),
  orderId: text('order_id')
    .notNull()
    .references(() => ordersTable.id),
  seatId: text('seat_id')
    .notNull()
    .references(() => seatsTable.id),
  price: decimal('price', { precision: 10, scale: 2 }).notNull(),
});
```

**Características:**
- ✅ Tipos tipados con Drizzle
- ✅ Relaciones definidas
- ✅ pgvector para embeddings
- ✅ Timestamps automáticos

---

## 5. FLUJO COMPLETO: Comprar entrada

```
POST /api/orders
  body: {
    performanceId: "perf_123",
    seatIds: ["seat_A12"]
  }

1. API Layer
   ├─ Auth middleware: verificar JWT
   ├─ Validation: Zod schema
   └─ Route handler → OrderService.checkout()

2. Domain Layer (OrderService)
   ├─ Validar que existen los asientos
   ├─ Validar disponibilidad (sin reserva temporal)
   ├─ Crear reserva temporal (5 minutos)
   ├─ Call PaymentService (simulado)
   ├─ Si pago OK:
   │  ├─ Crear Order en DB
   │  ├─ Marcar seats como "sold"
   │  └─ Limpiar reservas temporales
   └─ Return Order con confirmación

3. Infrastructure Layer
   ├─ Transacción DB (atomic)
   ├─ Update seats status
   ├─ Insert order
   └─ Commit

4. Response
   {
     success: true,
     data: {
       orderId: "ord_456",
       totalPrice: 150.00,
       seats: ["A12"],
       confirmationCode: "ABC123"
     }
   }

5. Background Job (próximo paso)
   ├─ Generar QR
   ├─ Enviar email de confirmación
   └─ Log a analytics
```

---

## 6. TESTING STRATEGY

### Unit Tests (Dominio)

```typescript
// tests/unit/domain/events.service.test.ts

describe('EventService', () => {
  let service: EventService;
  let repo: EventRepository;

  beforeEach(() => {
    repo = new EventRepository(); // Mock
    service = new EventService(repo);
  });

  it('should search events by genre', async () => {
    const events = await service.search({ genres: ['music'] });
    expect(events).toHaveLength(5);
  });

  it('should throw error for invalid price range', async () => {
    expect(() =>
      service.search({ priceRange: [100, 50] })
    ).toThrow('INVALID_PRICE_RANGE');
  });
});
```

### Integration Tests (API)

```typescript
// tests/integration/search.api.test.ts

describe('POST /api/search', () => {
  it('should search events using Claude tools', async () => {
    const response = await api.post('/api/search', {
      query: 'romantic events this weekend under €50',
    });

    expect(response.status).toBe(200);
    expect(response.body.data.recommendations).toBeDefined();
    expect(response.body.data.reasoning).toBeDefined();
  });

  it('should handle rate limiting', async () => {
    // 100 requests rápido
    for (let i = 0; i < 100; i++) {
      await api.post('/api/search', { query: 'test' });
    }

    // El 101º debe fallar
    const response = await api.post('/api/search', { query: 'test' });
    expect(response.status).toBe(429);
  });
});
```

---

## 7. CÓMO AGREGAR UNA NUEVA FEATURE

### Ejemplo: Agregar "Favoritos"

#### Paso 1: Domain

```typescript
// src/domain/favorites/favorite.entity.ts
export interface Favorite {
  id: string;
  userId: string;
  eventId: string;
  createdAt: Date;
}

// src/domain/favorites/favorite.service.ts
export class FavoriteService {
  constructor(private repo: FavoriteRepository) {}

  async add(userId: string, eventId: string): Promise<Favorite> {
    // Validar que evento existe
    // Validar que no está ya en favoritos
    // Crear y retornar
  }

  async remove(userId: string, eventId: string): Promise<void> {
    // Borrar
  }

  async list(userId: string): Promise<Favorite[]> {
    // Listar los favoritos del usuario
  }
}
```

#### Paso 2: Repository

```typescript
// src/domain/favorites/favorite.repository.ts
export class FavoriteRepository {
  async add(userId: string, eventId: string) {
    return db.insert(favoritesTable).values({ userId, eventId });
  }

  async list(userId: string) {
    return db.select().from(favoritesTable).where(eq(favoritesTable.userId, userId));
  }
}
```

#### Paso 3: API Routes

```typescript
// src/api/routes/favorites.ts
export async function favoriteRoutes(app: FastifyInstance) {
  app.post('/favorites/:eventId', async (req, reply) => {
    const { eventId } = req.params;
    const userId = req.user.id;

    const favorite = await FavoriteService.add(userId, eventId);
    return reply.code(201).send({ data: favorite });
  });

  app.get('/favorites', async (req, reply) => {
    const userId = req.user.id;
    const favorites = await FavoriteService.list(userId);
    return reply.send({ data: favorites });
  });
}
```

#### Paso 4: Tests

```typescript
// tests/unit/domain/favorites.service.test.ts
describe('FavoriteService', () => {
  it('should add favorite', async () => {
    await service.add('user_1', 'event_1');
    const favorites = await service.list('user_1');
    expect(favorites).toContainEqual({ eventId: 'event_1' });
  });
});

// tests/integration/favorites.api.test.ts
describe('POST /favorites/:eventId', () => {
  it('should add event to favorites', async () => {
    const response = await api.post('/favorites/event_1');
    expect(response.status).toBe(201);
  });
});
```

#### Paso 5: Registrar en app.ts

```typescript
// src/app.ts
import { favoriteRoutes } from './api/routes/favorites';

export async function createApp() {
  const app = Fastify();
  
  // ... otras routes
  await app.register(favoriteRoutes);
  
  return app;
}
```

---

## 8. PATRÓN DDD (Domain-Driven Design)

Tu backend sigue **Domain-Driven Design**:

```
Domain ← lo más importante (eventos, órdenes, butacas)
    ↑
    ├─ Entities (Event, Order, Seat)
    ├─ Services (EventService, OrderService)
    ├─ Repositories (EventRepository, OrderRepository)
    └─ Value Objects (Price, Email)

Application ← orquesta el dominio
    ↑
    ├─ APIs (routes)
    ├─ AI Handlers (Claude integration)
    ├─ MCP Server (admin interface)

Infrastructure ← detalles técnicos
    ├─ Database (Drizzle, PostgreSQL)
    ├─ Cache (Redis)
    └─ External services (Claude API)
```

**Ventaja:** El dominio NO conoce HTTP, DB, Claude. Totalmente aislado y testeable.

---

## 9. CHECKLIST DE IMPLEMENTACIÓN

- [ ] `packages/api/src/domain/events/` → Event service + repository
- [ ] `packages/api/src/domain/seats/` → Seat service + concurrency logic
- [ ] `packages/api/src/domain/orders/` → Order service
- [ ] `packages/api/src/infrastructure/db/schema.ts` → Drizzle schema
- [ ] `packages/api/src/infrastructure/db/connection.ts` → DB connection
- [ ] `packages/api/src/api/routes/events.ts` → GET/POST /events
- [ ] `packages/api/src/ai/tools/` → Registrar tools de Claude
- [ ] `packages/api/src/ai/handlers/search-handler.ts` → Multi-turn logic
- [ ] `packages/api/src/mcp/server.ts` → MCP setup
- [ ] Tests unitarios de cada service
- [ ] Tests de integración de cada API
- [ ] Tests de concurrencia (seats)

---

## TL;DR

**Backend = 3 capas limpias:**

1. **API** ← HTTP (rutas)
2. **Domain** ← Lógica (servicios)
3. **Infrastructure** ← Detalles (DB, cache, APIs externas)

**Flujo:** Request → Route → Service → Repository → DB

**Diferenciador:** AI y MCP son parte del sistema desde el inicio, no add-on.

¿Preguntas específicas sobre la estructura?

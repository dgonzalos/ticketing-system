# WORKFLOWS PRÁCTICOS + TROUBLESHOOTING — Windows 11

## WORKFLOWS DIARIOS

### WORKFLOW 1: Mañana - Crear Feature Nueva

```powershell
# 6:00 AM - Terminal PowerShell

# 1. Abrir proyecto
cd $HOME\dev\ticketing-system
code .

# 2. Ver qué necesitas hacer (checklist)
# Del documento "ticketing-cv-project-strategy.md"
# Hoy: Implementar SeatService

# 3. Pedir a Claude que cree
claude-code create @"
Crear SeatService en packages/api/src/domain/seats/seat.service.ts

Debe incluir:
- selectSeat(seatId, userId): Promise<{success: boolean}>
- deselectSeat(seatId, userId): Promise<void>
- confirmPurchase(seatIds[], userId): Promise<void>
- getPerformanceSeats(performanceId): Promise<Seat[]>

Usa SeatLockManager internamente para manejo de locks
"@

# Claude escribe el archivo automáticamente
# Toma ~30 segundos

# 4. Revisar en VS Code
# (ya está abierto en terminal anterior)

# 5. Si hay cambios, pedir ajustes
claude-code review "packages/api/src/domain/seats/seat.service.ts"
# "El método selectSeat debería retornar el expiresAt también"

# Claude ajusta automáticamente

# 6. Commitear
git add packages/api/src/domain/seats/seat.service.ts
git commit -m "feat: implement SeatService with lock management"

# 7. Pedir tests
claude-code test @"
Escribir tests para SeatService en packages/api/tests/unit/domain/seats.service.test.ts

Casos de prueba:
- selectSeat: butaca disponible → success true
- selectSeat: butaca ocupada → success false
- deselectSeat: libera correctamente
- confirmPurchase: convierte locks a sold
- getPerformanceSeats: retorna array tipado

Usa Vitest
"@

# 8. Correr tests
pnpm -r --filter @ticketing/api test

# 9. Verificar cobertura
pnpm -r --filter @ticketing/api test:coverage

# 10. Commitear tests
git add packages/api/tests/
git commit -m "test: add SeatService unit tests (95% coverage)"

# 11. Push a GitHub (cuando tengas remote)
git push

# Total: ~1 hora para feature completa con tests ✓
```

### WORKFLOW 2: Medio Día - Integración con API

```powershell
# 12:00 PM

# Ahora crear las rutas HTTP que usan SeatService

claude-code create @"
Crear API routes en packages/api/src/api/routes/seats.ts

Endpoints:
1. POST /seats/:seatId/select
   - Auth required
   - Llama seatService.selectSeat()
   - Retorna { success, expiresAt }
   - 409 si no disponible

2. DELETE /seats/:seatId/select
   - Auth required
   - Llama seatService.deselectSeat()

3. POST /seats/check-availability
   - Body: { seatIds: string[] }
   - Retorna { [seatId]: boolean }

Usa FastifyRequest, FastifyReply
Usa Zod para validation
"@

# Claude crea las rutas

# Revisar
claude-code review "packages/api/src/api/routes/seats.ts"

# Integrar en app.ts
claude-code create @"
En packages/api/src/app.ts

Agregar import:
import { seatRoutes } from './api/routes/seats';

En createApp():
await app.register(seatRoutes);
"@

# Verificar que compila
pnpm -r --filter @ticketing/api build

# Si error → Claude lo arregla
# Si OK → commitear
git add packages/api/src/api/routes/seats.ts
git add packages/api/src/app.ts
git commit -m "feat: add seat selection API routes"
```

### WORKFLOW 3: Tarde - Testing de Integración

```powershell
# 16:00 PM

# Crear tests de integración (E2E local)

claude-code test @"
Crear tests de integración en packages/api/tests/integration/seat-api.test.ts

Tests:
1. POST /seats/seat_A12/select → 200 con expiresAt
2. POST /seats/seat_A12/select (dos usuarios paralelo) → uno 200, otro 409
3. DELETE /seats/seat_A12/select → 200
4. POST /seats/check-availability → objeto con true/false

Usa supertest para hacer requests
Setup: crear DB test con datos
Cleanup: borrar después

Simular race condition con Promise.all()
"@

# Correr tests
pnpm -r --filter @ticketing/api test:integration

# Si falla → pedir ajustes a Claude
claude-code review "tests/integration/seat-api.test.ts"

# Cuando pase → commitear
git add packages/api/tests/integration/
git commit -m "test: add seat API integration tests with race conditions"
```

### WORKFLOW 4: Noche - Documentación

```powershell
# 20:00 PM

# Documentar lo que hiciste

claude-code create @"
Crear documentación en docs/SEAT_CONCURRENCY.md

Secciones:
1. Problema (race conditions)
2. Solución (temporal locks)
3. Schema DB (reservedUntil, reservedBy)
4. API endpoints (POST/DELETE)
5. Ejemplo de flujo (usuario selecciona → paga → confirmación)
6. Cómo testear (Promise.all para simular)

Formato: Markdown con ejemplos de código
"@

# Revisar
claude-code review "docs/SEAT_CONCURRENCY.md"

# Agregar a git
git add docs/SEAT_CONCURRENCY.md
git commit -m "docs: explain seat concurrency implementation"

# Verificar estado
git log --oneline
# Debería mostrar:
# - feat: implement SeatService
# - test: add SeatService tests
# - feat: add seat selection routes
# - test: add integration tests
# - docs: explain implementation

# Todo en 1 día ✓
```

---

## WORKFLOW CON CLAUDE AI (Navegador + Terminal)

### Cuando preguntas son más abstractas

```powershell
# Escenario: "¿Cómo integro MCP Server sin duplicar código?"

# 1. Terminal
cd $HOME\dev\ticketing-system

# 2. Crear documento con contexto
@"
# MCP Server Architecture Question

## Current structure
- packages/api/src/ai/tools/ (SearchEventsTool, etc)
- packages/api/src/domain/ (Services)
- Quiero agregar MCP server

## Question
¿Cómo evito duplicar AnalyzeSalesTool entre:
- API routes (POST /analyze)
- MCP Server (analyze_sales_patterns tool)

## Options considero
A) Una clase base, dos implementations
B) MCP server llama servicios de dominio
C) CLI que ejecuta directamente MCP

## Preference
Mantenibilidad + Type safety
"@ | Out-File architecture-question.md

notepad architecture-question.md

# 3. Abrir Claude en navegador
Start-Process "https://claude.ai"

# 4. En Claude: copiar contenido de architecture-question.md
# Claude da feedback detallado

# 5. Implementar basado en recomendación
claude-code create "Crear ToolsRegistry en packages/api/src/ai/tools/tools.registry.ts"

# (Más eficiente que esperar a que Claude traduzca todo)
```

---

## TROUBLESHOOTING COMÚN

### Problema 1: `ANTHROPIC_API_KEY not found`

```powershell
# Error:
# Error: ANTHROPIC_API_KEY not set

# Solución:

# Verificar que está seteada
echo $env:ANTHROPIC_API_KEY

# Si está vacía:
# 1. Ir a https://console.anthropic.com
# 2. Copiar API Key
# 3. Ejecutar:

[Environment]::SetEnvironmentVariable("ANTHROPIC_API_KEY", "sk-ant-XXX", "User")

# 4. Cerrar PowerShell completamente
# 5. Abrir nueva ventana
# 6. Verificar
echo $env:ANTHROPIC_API_KEY
# Debería mostrar tu key
```

### Problema 2: `command not found: claude-code`

```powershell
# Error:
# claude-code : The term 'claude-code' is not recognized

# Solución:

# Verificar que está instalado
npm list -g @anthropic-ai/claude-code

# Si no está:
npm install -g @anthropic-ai/claude-code

# Si sigue fallando, añadir a PATH:
$npmPath = npm prefix -g
[Environment]::SetEnvironmentVariable("PATH", "$npmPath\bin;$env:PATH", "User")

# Cerrar PowerShell y abrir de nuevo
```

### Problema 3: Errores de TypeScript

```powershell
# Error durante pnpm build:
# error TS2307: Cannot find module '@/domain/...'

# Solución:

# 1. Verificar que tsconfig.json tiene paths correctos
cat packages/api/tsconfig.json

# 2. Debería tener:
# "paths": {
#   "@/*": ["src/*"]
# }

# 3. Si no, pedir a Claude que lo arregle
claude-code review "packages/api/tsconfig.json"
```

### Problema 4: Git merge conflicts

```powershell
# Si tienes conflictos (raro, pero puede pasar)

# Ver conflictos
git status

# Abrir archivo conflictivo
code "archivo-con-conflicto.ts"

# Resolver manualmente en VS Code
# (Debería mostrar opciones "Accept current" / "Accept incoming")

# Despues
git add "archivo-con-conflicto.ts"
git commit -m "chore: resolve merge conflict"
```

### Problema 5: Pnpm no reconoce workspaces

```powershell
# Error:
# ERR_PNPM_WORKSPACE_NOT_FOUND

# Solución:

# Verificar que existe pnpm-workspace.yaml en raíz
ls pnpm-workspace.yaml

# Si no existe:
claude-code create "Crear pnpm-workspace.yaml en raíz con packages/* path"

# Reinstalar
pnpm install
```

### Problema 6: Tests fallan pero código se ve bien

```powershell
# Ejecutar con verbosity
pnpm -r --filter @ticketing/api test -- --reporter=verbose

# Ver logs detallados
pnpm -r --filter @ticketing/api test -- --reporter=verbose 2>&1 | Out-File test-log.txt

notepad test-log.txt

# Si error de timeout:
# En vitest.config.ts agregar:
# testTimeout: 10000

# Pedir a Claude que lo arregle
claude-code review "packages/api/vitest.config.ts"
```

### Problema 7: Claude Code toma demasiado tiempo

```powershell
# Si demora >2 minutos

# Opción 1: Solicitud muy grande
# Dividir en partes más pequeñas

# Antes (lento):
claude-code create "Crear SeatService, SeatRepository, SeatEntity, todas las relaciones..."

# Después (rápido):
claude-code create "Crear SeatEntity en packages/api/src/domain/seats/seat.entity.ts"
claude-code create "Crear SeatRepository en packages/api/src/domain/seats/seat.repository.ts"
claude-code create "Crear SeatService en packages/api/src/domain/seats/seat.service.ts"

# Opción 2: Conexión lenta
# Verificar internet
Test-NetConnection "api.anthropic.com" -Port 443

# Opción 3: Rate limit
# Esperar 60 segundos
Start-Sleep -Seconds 60
```

---

## TIPS DE PRODUCTIVIDAD

### Tip 1: Usar archivos CLAUDE.md

```powershell
# En raíz del proyecto

# Crear CLAUDE.md con contexto

@"
# Ticketing System - Context para Claude

## Stack
- Frontend: React 18 + Vite + TypeScript + TanStack Query + Tailwind
- Backend: Fastify + TypeScript + Drizzle ORM
- DB: PostgreSQL + pgvector
- AI: Claude API (tools, structured outputs)
- MCP: Admin backend

## Patrones
- Domain-Driven Design
- Repository pattern
- Zod para validation
- Vitest para tests

## Convenciones
- Archivos: snake_case (seat-lock.ts)
- Tipos: PascalCase (SeatLockManager)
- Métodos: camelCase
- DB fields: snake_case

## Rutas
- Backend: packages/api/src/
- Frontend: packages/web/src/
- Shared: packages/shared/

## Cómo me relaciono con esto
Como desarrollador solicitando features a través de Claude Code
"@ | Out-File CLAUDE.md

# Claude leerá esto automáticamente en próximas solicitudes
```

### Tip 2: Crear scripts personalizado

```powershell
# En PowerShell profile

# Función para crear feature completa

function new-feature {
    param(
        [string]$name,
        [string]$description
    )
    
    Write-Host "🚀 Creating feature: $name"
    
    # Crear servicio
    claude-code create "Crear ${name}Service"
    
    # Crear tests
    claude-code test "Crear tests para ${name}Service"
    
    # Crear routes
    claude-code create "Crear API routes para $name"
    
    # Commitear
    git add .
    git commit -m "feat: implement $name"
    
    Write-Host "✅ Feature $name created and committed"
}

# Uso:
new-feature "FavoriteService" "Users can favorite events"
```

### Tip 3: Parallelize con múltiples terminales

```powershell
# Terminal 1: Development
cd $HOME\dev\ticketing-system
pnpm dev

# Terminal 2: Tests
cd $HOME\dev\ticketing-system
pnpm -r --filter @ticketing/api test:watch

# Terminal 3: Claude Code
cd $HOME\dev\ticketing-system
claude-code create "..."

# Terminal 4: Git
cd $HOME\dev\ticketing-system
git log --oneline
git diff
```

### Tip 4: Documentar todo en real-time

```powershell
# Mientras desarrollas

# Crear archivo de notas
@"
# Development Log - $(Get-Date -Format yyyy-MM-dd)

## Completed
- [ ] Implement SeatLockManager

## In Progress
- [ ] API routes for seat selection

## Next
- [ ] Integration tests with race conditions
- [ ] Document concurrency pattern

## Blockers
- None yet
"@ | Out-File dev-log.md

# Actualizar conforme avanzas
# Al final del día:
# git add dev-log.md && git commit -m "docs: update dev log"
```

---

## MONITOREO DE PRODUCTIVIDAD

### Métricas para trackear

```powershell
# Ver commits por día
git log --oneline --since="1 week ago" | wc -l

# Ver líneas de código
git diff --stat HEAD~10

# Ver test coverage
pnpm -r --filter @ticketing/api test:coverage

# Ver tiempo promedio por feature
git log --oneline | head -20
# (deberías ver ~3-5 commits por día)
```

---

## SCRIPT AUTOMÁTICO PARA START DE DÍA

```powershell
# Crear archivo: daily-setup.ps1

@"
# Daily Setup Script

# 1. Verificar que todo está OK
Write-Host "🔍 Checking environment..."
echo "Node: $(node --version)"
echo "NPM: $(npm --version)"
echo "Git: $(git --version)"
echo "Claude Code: $(claude-code --version)"

# 2. Actualizar repo
Write-Host "📥 Pulling latest changes..."
git pull

# 3. Instalar dependencias (si necesario)
Write-Host "📦 Installing dependencies..."
pnpm install

# 4. Ejecutar tests
Write-Host "🧪 Running tests..."
pnpm -r test -- --reporter=verbose

# 5. Abrir VS Code
Write-Host "📝 Opening VS Code..."
code .

Write-Host "✅ Ready to code!"
"@ | Out-File daily-setup.ps1

# Uso:
# .\daily-setup.ps1
```

---

## RESUMEN: TU WORKFLOW IDEAL

```
08:00 - .\daily-setup.ps1
08:05 - Ver qué hacer hoy
08:10 - claude-code create "feature X"
08:30 - Revisar en VS Code
08:45 - claude-code test "tests"
09:00 - pnpm test
09:15 - git commit
10:00 - Siguiente feature

REPETIR 3-4 veces por día = 3-4 features/día ✓
```

---

## ÚLTIMA COSA: GitHub

Cuando tengas listo:

```powershell
# 1. Crear repo en GitHub
# https://github.com/new

# 2. Conectar local
git remote add origin https://github.com/tu-usuario/ticketing-system.git
git branch -M main
git push -u origin main

# 3. Cada día
git push

# Ahora GitHub mostrará:
# - Commits diarios
# - Contribution graph
# - Code organization
# (Esto es lo que ven los recruiters)
```

---

**¿Lista para empezar?** 🚀

Toma los primeros 30 minutos mañana para hacer el setup, y luego estás listo para crear features.

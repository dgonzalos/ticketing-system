# Estrategia: Ticketing System con Claude AI — Máximo Impacto en CV

## 1. POSICIONAMIENTO

**No es:** "Una ticketera normal en React + Node"

**Es:** "Un sistema de venta de entradas que demuestra integración profesional de Claude API, MCP y product thinking, con full-stack execution."

---

## 2. ARQUITECTURA CONCEPTUAL

```
┌─────────────────────────────────────────────────────────────┐
│                      USUARIO FINAL                           │
│                   (Comprador de tickets)                      │
└────────────────┬────────────────────────────────────────────┘
                 │
         ┌───────▼────────┐
         │   React + Vite  │ (TanStack Query + TypeScript)
         └───────┬────────┘
                 │
         ┌───────▼────────────────────┐
         │   API Layer (Fastify)       │
         │                            │
         │  • REST endpoints          │
         │  • Auth (JWT)              │
         │  • Request validation      │
         └───────┬────────────────────┘
                 │
         ┌───────▼────────────────────────────┐
         │   Application Layer                │
         │                                   │
         │  • Domain logic                   │
         │  • Seat management               │
         │  • Order processing              │
         │  • Concurrency handling          │
         └───────┬────────────────────────────┘
                 │
      ┌──────────┼──────────┬─────────────┐
      │          │          │             │
   ┌──▼──┐  ┌──▼──┐  ┌──▼───┐  ┌──▼────┐
   │ DB  │  │ AI  │  │ MCP  │  │Cache  │
   │(PG) │  │API  │  │Srvr  │  │(Redis)│
   └─────┘  └─────┘  └──────┘  └───────┘
```

---

## 3. FEATURES CORE (MVP)

### 3.1 Features de Negocio
- ✅ CRUD eventos y funciones
- ✅ Mapa de butacas con selección visual
- ✅ Reserva temporal (bloqueo de butacas)
- ✅ Compra con pago simulado
- ✅ Validación de disponibilidad (concurrency)
- ✅ Email de confirmación

### 3.2 Features de AI (Diferenciador)
**Aquí es donde brillas:**

#### A. AI Assistant para recomendaciones
```javascript
// El usuario describe qué busca, Claude entiende y recomienda
"Quiero algo para una primera cita, romántico, no muy caro"
  ↓
Claude con tool use
  ↓
POST /api/events/search → búsqueda + ranking
  ↓
Retorna eventos ordenados
```

**Tools disponibles:**
- `search_events` — Filtra por género, rango de precio, fecha
- `get_event_details` — Info completa de evento
- `check_availability` — Disponibilidad en tiempo real

#### B. AI-powered admin features (MCP Server)
```
Admin backend → MCP Server con Claude
  ├─ Analyze sales patterns
  ├─ Detect fraud (patrones raros de compra)
  ├─ Generate reports
  └─ Price optimization suggestions
```

**Resources MCP:**
- `/events/{id}/analytics` — Datos de venta en tiempo real
- `/orders/analysis` — Pattern detection
- `/revenue/forecast` — Predicciones

#### C. Structured Outputs para análisis
```typescript
const analysisSchema = z.object({
  event_id: z.string(),
  demand_level: z.enum(['low', 'medium', 'high']),
  recommended_price: z.number(),
  fraud_score: z.number().min(0).max(1),
  recommendations: z.array(z.string()),
  confidence: z.number()
});

// Claude devuelve JSON estructurado, no texto
const result = await claude.messages.create({
  model: "claude-opus-4",
  temperature: 1,
  response_format: {
    type: "json_schema",
    json_schema: {
      name: "event_analysis",
      schema: analysisSchema
    }
  }
});
```

---

## 4. STACK TÉCNICO DETALLADO

### Frontend
```
ticketing-app/
├── src/
│   ├── components/
│   │   ├── ui/              # Button, Input, Modal, etc.
│   │   └── domain/          # EventCard, SeatMap, OrderForm
│   ├── features/
│   │   ├── events/
│   │   │   ├── api/         # useEvents, useEventDetails
│   │   │   ├── hooks/       # useEventFilters, useSeats
│   │   │   └── components/
│   │   ├── search/          # Claude AI search integration
│   │   ├── checkout/        # Payment flow
│   │   └── orders/          # Order history
│   ├── lib/
│   │   ├── api.ts           # Fetch wrapper + error handling
│   │   ├── types.ts         # Shared types from backend
│   │   └── constants.ts
│   └── theme/               # Tailwind + design tokens
├── vite.config.ts
├── tsconfig.json
└── README.md

Stack:
- React 18
- Vite
- TypeScript
- TanStack Query v5
- React Router v7
- Tailwind CSS
- Zod (validation)
- Vitest + Testing Library
- Playwright (E2E)
```

### Backend
```
ticketing-api/
├── src/
│   ├── api/
│   │   ├── routes/
│   │   │   ├── events.ts
│   │   │   ├── performances.ts
│   │   │   ├── seats.ts
│   │   │   ├── orders.ts
│   │   │   └── auth.ts
│   │   └── middleware/
│   │       ├── auth.ts
│   │       ├── validation.ts
│   │       └── error-handler.ts
│   │
│   ├── domain/
│   │   ├── events/
│   │   │   ├── event.ts      # Entity
│   │   │   ├── event.repo.ts # Repository
│   │   │   └── event.service.ts
│   │   ├── seats/
│   │   │   ├── seat.ts
│   │   │   ├── seat-lock.ts  # Temporal locks
│   │   │   └── concurrency.ts
│   │   └── orders/
│   │       ├── order.ts
│   │       └── order.service.ts
│   │
│   ├── ai/
│   │   ├── claude-client.ts  # Claude API wrapper
│   │   ├── tools/
│   │   │   ├── search-events.ts
│   │   │   ├── get-details.ts
│   │   │   └── check-availability.ts
│   │   └── schemas/          # Zod schemas para structured outputs
│   │
│   ├── mcp/
│   │   ├── server.ts         # MCP server setup
│   │   ├── tools/
│   │   │   ├── analyze-sales.ts
│   │   │   └── detect-fraud.ts
│   │   └── resources/
│   │       ├── analytics.ts
│   │       └── forecasts.ts
│   │
│   ├── infrastructure/
│   │   ├── db/
│   │   │   ├── migrations/
│   │   │   ├── connection.ts
│   │   │   └── seeds/
│   │   ├── cache.ts          # Redis
│   │   └── config.ts
│   │
│   └── app.ts               # Fastify setup
│
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/
│
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md

Stack:
- Fastify (alternativa: Hono)
- TypeScript
- Drizzle ORM (o Prisma)
- PostgreSQL + pgvector
- Zod (schemas + validation)
- Vitest
- pino (logging)
- Anthropic SDK
- MCP SDK
```

### Database Schema (Conceptual)

```sql
-- Events
CREATE TABLE events (
  id UUID PRIMARY KEY,
  title VARCHAR NOT NULL,
  description TEXT,
  genre VARCHAR,
  price_range DECIMAL[],
  created_at TIMESTAMP,
  embedding vector(1536)  -- pgvector para búsqueda semántica
);

-- Performances (funciones)
CREATE TABLE performances (
  id UUID PRIMARY KEY,
  event_id UUID REFERENCES events,
  date TIMESTAMP NOT NULL,
  venue VARCHAR,
  capacity INT,
  current_sales INT DEFAULT 0
);

-- Seats
CREATE TABLE seats (
  id UUID PRIMARY KEY,
  performance_id UUID REFERENCES performances,
  row CHAR,
  number INT,
  zone VARCHAR,
  price DECIMAL,
  status ENUM('available', 'reserved', 'sold', 'blocked'),
  reserved_until TIMESTAMP NULL,  -- Para bloqueos temporales
  reserved_by UUID NULL           -- Usuario que reservó
);

-- Orders
CREATE TABLE orders (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  performance_id UUID REFERENCES performances,
  total_price DECIMAL,
  status ENUM('pending', 'completed', 'cancelled'),
  created_at TIMESTAMP,
  completed_at TIMESTAMP
);

-- Order items (qué butacas incluye)
CREATE TABLE order_items (
  id UUID PRIMARY KEY,
  order_id UUID REFERENCES orders,
  seat_id UUID REFERENCES seats,
  price DECIMAL
);

-- Analytics para AI
CREATE TABLE sales_analytics (
  id UUID PRIMARY KEY,
  performance_id UUID REFERENCES performances,
  hour TIMESTAMP,
  sales_count INT,
  revenue DECIMAL,
  available_seats INT
);
```

---

## 5. FEATURES DE AI ESPECÍFICAS PARA DEMOSTRAR

### 5.1 Búsqueda inteligente con Claude + Tool Use

```typescript
// En el backend
app.post('/api/search', async (req, res) => {
  const { query } = req.body;  // "Quiero algo romántico para el fin de semana"
  
  const response = await claude.messages.create({
    model: "claude-opus-4",
    max_tokens: 1024,
    tools: [
      {
        name: "search_events",
        description: "Search events by various criteria",
        input_schema: {
          type: "object",
          properties: {
            genres: { type: "array", items: { type: "string" } },
            min_price: { type: "number" },
            max_price: { type: "number" },
            from_date: { type: "string" },
            to_date: { type: "string" }
          }
        }
      },
      {
        name: "get_event_details",
        description: "Get full details of an event",
        input_schema: {
          type: "object",
          properties: { event_id: { type: "string" } }
        }
      }
    ],
    messages: [
      {
        role: "user",
        content: query
      }
    ]
  });
  
  // Procesar tool calls y retornar resultados
  return res.send(processToolCalls(response));
});
```

### 5.2 Análisis de patrones con Structured Outputs

```typescript
// Endpoint para admin: /api/admin/analyze-performance/:id
app.get('/api/admin/analyze-performance/:id', async (req, res) => {
  const performance = await getPerformance(req.params.id);
  const orders = await getOrdersForPerformance(req.params.id);
  const seats = await getSeatsForPerformance(req.params.id);
  
  const analysis = await claude.messages.create({
    model: "claude-opus-4",
    temperature: 1,
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "performance_analysis",
        schema: z.object({
          demand_level: z.enum(['low', 'medium', 'high']),
          sold_percentage: z.number(),
          peak_buying_hours: z.array(z.string()),
          recommended_actions: z.array(z.string()),
          price_optimization: z.object({
            current_avg_price: z.number(),
            suggested_price: z.number(),
            expected_revenue_increase: z.number()
          }),
          anomalies: z.array(z.object({
            type: z.string(),
            severity: z.enum(['low', 'medium', 'high']),
            description: z.string()
          }))
        })
      }
    },
    messages: [
      {
        role: "user",
        content: `Analiza esta función: ${JSON.stringify({
          title: performance.title,
          date: performance.date,
          capacity: performance.capacity,
          sold: orders.length,
          orders_timeline: orders.map(o => ({ time: o.created_at, amount: o.total_price })),
          zone_distribution: calculateZoneDistribution(seats)
        })}`
      }
    ]
  });
  
  return res.send(analysis.content[0]);
});
```

### 5.3 MCP Server para Admin Backend

```typescript
// mcp-server.ts
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

const server = new Server({
  name: "ticketing-admin",
  version: "1.0.0"
});

// Tools MCP
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "analyze_sales_patterns",
      description: "Deep analysis of sales patterns for a performance",
      inputSchema: {
        type: "object",
        properties: {
          performance_id: { type: "string" },
          time_range: { type: "string", enum: ["24h", "7d", "30d"] }
        }
      }
    },
    {
      name: "detect_fraudulent_orders",
      description: "Detect potential fraud in recent orders",
      inputSchema: {
        type: "object",
        properties: {
          lookback_hours: { type: "number" }
        }
      }
    },
    {
      name: "suggest_price_changes",
      description: "Suggest dynamic pricing changes",
      inputSchema: {
        type: "object",
        properties: {
          performance_id: { type: "string" },
          timeframe: { type: "string" }
        }
      }
    }
  ]
}));

// Resources MCP
server.setRequestHandler(ListResourcesRequestSchema, async () => ({
  resources: [
    {
      uri: "analytics://events/top-performers",
      name: "Top performing events",
      mimeType: "application/json"
    },
    {
      uri: "analytics://orders/recent-anomalies",
      name: "Recent order anomalies",
      mimeType: "application/json"
    }
  ]
}));
```

---

## 6. ESTRUCTURA DE GITHUB

```
ticketing-system/
├── README.md                 # ⭐ Ver sección 7
├── .github/
│   └── workflows/
│       ├── test.yml
│       ├── deploy.yml
│       └── code-quality.yml
│
├── packages/
│   ├── api/                  # Backend (Fastify + Claude)
│   │   ├── src/
│   │   ├── tests/
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   ├── web/                  # Frontend (React + Vite)
│   │   ├── src/
│   │   ├── tests/
│   │   └── package.json
│   │
│   ├── shared/               # Tipos compartidos
│   │   └── types.ts
│   │
│   └── mcp-server/           # MCP Server standalone
│       ├── src/
│       └── package.json
│
├── infrastructure/
│   ├── docker-compose.yml
│   ├── docker-compose.prod.yml
│   ├── postgres/
│   │   ├── init.sql
│   │   └── migrations/
│   └── nginx/
│       └── nginx.conf
│
├── docs/
│   ├── ARCHITECTURE.md       # Arquitectura técnica
│   ├── AI-INTEGRATION.md     # Cómo funciona Claude
│   ├── MCP-SERVER.md         # MCP setup
│   ├── API.md                # OpenAPI/Swagger
│   └── DEPLOYMENT.md
│
├── .env.example
├── pnpm-workspace.yaml       # Monorepo
└── package.json
```

---

## 7. README.md — LA PIEZA CRÍTICA

```markdown
# Ticketing System — Full-Stack with Claude AI & MCP

A production-grade event ticketing platform showcasing:
- **Full-stack architecture**: React + Fastify + PostgreSQL
- **Claude API integration**: Tool use, structured outputs, semantic search
- **MCP Server**: Admin analytics with agentic capabilities
- **Real-world patterns**: Seat concurrency, dynamic pricing, fraud detection

## 🎯 Why This Project?

This is not just another ticketing app. It demonstrates:

### 1. **Full-Stack Mastery**
- React + TypeScript frontend with proper state management (TanStack Query)
- Fastify backend with domain-driven architecture
- PostgreSQL with pgvector for AI-powered search
- Docker + CI/CD for production readiness

### 2. **Claude API Integration** (from "Building with Claude API" course)
- **Tool use**: Search events, get details, check availability
- **Structured outputs**: JSON schema validation for admin analytics
- **Multi-turn conversations**: Smart event recommendations
- **Error handling & streaming**: Production patterns

### 3. **MCP Server** (from "Introduction to Model Context Protocol" course)
- Admin backend with tools: sales analysis, fraud detection, price optimization
- Resources: analytics dashboards, forecasts
- Agentic workflows for business intelligence

### 4. **Product Thinking**
- Concurrency handling (seat reservations with temporal locks)
- API design with clear contracts (OpenAPI)
- Comprehensive testing strategy
- Proper error taxonomy and handling

## 🚀 Quick Start

### Prerequisites
- Node.js 20+
- Docker + Docker Compose
- PostgreSQL 15+

### Development
```bash
pnpm install
pnpm dev
```

This runs:
- Frontend: http://localhost:5173
- Backend: http://localhost:3000
- MCP Server: Unix socket (for admin CLI)

### Production
```bash
docker-compose -f docker-compose.prod.yml up
```

## 📚 Documentation

- **[ARCHITECTURE.md](./docs/ARCHITECTURE.md)** — System design, layer breakdown
- **[AI-INTEGRATION.md](./docs/AI-INTEGRATION.md)** — How Claude is integrated
- **[MCP-SERVER.md](./docs/MCP-SERVER.md)** — MCP server setup and usage
- **[API.md](./docs/API.md)** — Complete API reference (OpenAPI 3.0)
- **[DEPLOYMENT.md](./docs/DEPLOYMENT.md)** — Production deployment

## 🤖 AI Features

### 1. Smart Event Search
```bash
curl -X POST http://localhost:3000/api/search \
  -H "Content-Type: application/json" \
  -d '{"query": "I want something romantic for this weekend, under €50"}'
```

Claude understands natural language, uses tools to search, and returns ranked results.

### 2. Admin Analytics (MCP)
```bash
# Connect Claude to the MCP server for admin insights
claude admin-ticket-analyzer

> analyze performance for event_123 in the last 7 days
```

Claude calls MCP tools to analyze sales patterns, detect anomalies, and suggest pricing.

### 3. Fraud Detection
Real-time detection of suspicious orders using structured outputs.

## 🧪 Testing

```bash
# Unit tests
pnpm test

# Integration tests
pnpm test:integration

# E2E tests (Playwright)
pnpm test:e2e

# Coverage
pnpm test:coverage
```

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, TypeScript, TanStack Query, Tailwind |
| Backend | Fastify, TypeScript, Drizzle ORM, PostgreSQL, pgvector |
| AI | Claude API (tool use, structured outputs) |
| MCP | MCP Server with tools & resources |
| Infrastructure | Docker, Docker Compose, GitHub Actions |

## 🔄 CI/CD

- **Test**: Run on every PR
- **Build**: Docker image creation
- **Deploy**: Automated to staging/production
- **Monitor**: Error tracking with Sentry (optional)

## 🎓 Learning Resources

This project demonstrates concepts from:
- [Building with the Claude API](https://anthropic.skilljar.com/...)
- [Introduction to Model Context Protocol](https://anthropic.skilljar.com/...)
- [Claude Code in Action](https://anthropic.skilljar.com/...)

## 📄 License

MIT

## 👤 Author

Diego — Full-stack engineer focused on AI integration.

---

**Looking for the code?** Start with [`packages/api/README.md`](./packages/api/README.md) for the backend architecture.
```

---

## 8. TIMELINE DE DESARROLLO

### Fase 0: Setup (Semana 1)
- [ ] Monorepo con pnpm workspaces
- [ ] Vite + React base
- [ ] Fastify base
- [ ] Docker Compose setup
- [ ] Database schema + migrations
- [ ] GitHub Actions CI/CD básico

### Fase 1: Core Ticketing (Semanas 2-3)
- [ ] Auth (JWT)
- [ ] CRUD eventos y funciones
- [ ] Mapa de butacas (visual component)
- [ ] Reserva de butacas con locks
- [ ] Validación de concurrencia
- [ ] Order checkout básico

### Fase 2: AI Integration (Semana 4)
- [ ] Claude API client wrapper
- [ ] Tool definitions (search, details, availability)
- [ ] Natural language search endpoint
- [ ] UI para recomendaciones

### Fase 3: MCP Server (Semana 5)
- [ ] MCP server setup
- [ ] Admin tools (analysis, fraud detection)
- [ ] Resources (analytics)
- [ ] CLI client para testing

### Fase 4: Polish & Docs (Semana 6)
- [ ] Tests (unit + integration + E2E)
- [ ] API documentation (OpenAPI)
- [ ] Architecture docs
- [ ] Deployment guide
- [ ] README completo

---

## 9. DIFERENCIADORES EN GitHub

**NO hagas esto:**
```
┌─ Frontend
├─ Backend
└─ README con 3 líneas
```

**Haz esto:**
```
┌─ EXCELENTE README
│  (Explica qué es, por qué, cómo usarlo, documentación de AI)
│
├─ Documentación de arquitectura
│  (Diagramas, decisiones de diseño)
│
├─ Code bien estructurado
│  (Clean code, tests, sin magic numbers)
│
├─ AI como diferenciador real
│  (No "agregué Claude porque sí", sino "Claude resuelve X problema")
│
└─ Deployment ready
   (Docker, CI/CD, env vars example)
```

---

## 10. CÓMO VENDERLO EN CV

**Copia esto en tu CV:**

> "Full-stack ticketing platform with Claude API & MCP integration. 
> Demonstrates: REST API design, React + TypeScript, PostgreSQL, 
> tool use workflows, structured outputs for analytics, agentic MCP server 
> for admin intelligence. Production-ready with Docker & CI/CD."

**En LinkedIn:**

> "Just shipped a ticketing system that showcases everything from the 
> @anthropic Claude API and MCP courses. Using tool use to power intelligent 
> event search, structured outputs for fraud detection, and an MCP server 
> that lets admins ask natural language questions about their business. 
> Full-stack: React → Fastify → PostgreSQL. 
> 
> Link: [GitHub]"

---

## 11. CHECKLIST ANTES DE PUBLICAR

- [ ] README impecable con ejemplos
- [ ] Archivo ARCHITECTURE.md (con diagramas)
- [ ] API documentation (OpenAPI YAML)
- [ ] AI-INTEGRATION.md explicando tool use y structured outputs
- [ ] MCP-SERVER.md con ejemplos de uso
- [ ] Tests con >70% coverage
- [ ] .env.example con todas las variables
- [ ] docker-compose.yml que funcione en un comando
- [ ] GitHub Actions workflows (test + deploy)
- [ ] License (MIT)
- [ ] Issues/Discussions habilitados
- [ ] 2-3 commits iniciales bien documentados

---

## 12. EXTRA: Hacer aún más "wow"

**Opcionales pero poderosos:**

1. **Video demo** (5 min) en GitHub
   - Mostrar búsqueda natural → Claude API → resultados
   - MCP server haciendo análisis en vivo

2. **Swagger UI** en `/api/docs`
   - Interactive API explorer

3. **Admin dashboard** (bonus)
   - Gráficos con datos reales
   - MCP insights integrados

4. **Blog post** sobre la integración
   - "Cómo integré Claude en un sistema real"
   - Link en GitHub

5. **Open issues** bien etiquetadas
   - Invita a colaboradores
   - Muestra que estás activo

---

## TL;DR

**Tu proyecto de CV debería:**

1. ✅ Ser **completo**: frontend + backend + DB
2. ✅ Integrar **Claude realmente** (no como afterthought)
3. ✅ Mostrar **MCP** (diferenciador)
4. ✅ Tener **tests** (demuestras profesionalismo)
5. ✅ Estar **documentado** (README impecable)
6. ✅ Ser **deployable** (Docker + CI/CD)
7. ✅ Resolver **un problema real** (concurrency, recommendations)

Esto te diferencia de "hola, hice un CRUD" a "sé cómo integrar IA profesionalmente en software real".
